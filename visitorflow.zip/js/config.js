const CONFIG = {
    SCRIPT_URL: 'https://script.google.com/macros/s/AKfycbw6MK1i-ZTrOmoROPG63-MIfMTkQgHw54QhcyN9PHHye0VNdjt-P17ktO2bahDJbkcSDQ/exec',
    AUTH_TOKEN: 'YOUR_AUTH_TOKEN',
    MOCK: {
        OTP: '1234',
        KNOWN_USERS: new Set() // Store known phone numbers
    }
};